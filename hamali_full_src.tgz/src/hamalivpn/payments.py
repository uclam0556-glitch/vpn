import hashlib
import logging
import os
from datetime import UTC, datetime, timedelta
from urllib.parse import urlencode

from aiogram import F, Router
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    LabeledPrice,
    Message,
    PreCheckoutQuery,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy import select

from .config import get_settings
from .db import SessionFactory
from .models import (
    Customer,
    PaymentStatus,
    PaymentTransaction,
    Subscription,
    SubscriptionStatus,
    as_utc,
)
from .remnawave import RemnawaveError, make_remnawave_gateway
from .services import get_latest_subscription, issue_trial

logger = logging.getLogger(__name__)
settings = get_settings()
router = Router()

PLANS = {
    "1_month": {"name": "1 Месяц", "price": 100, "days": 30},
    "3_months": {"name": "3 Месяца", "price": 250, "days": 90},
    "6_months": {"name": "6 Месяцев", "price": 450, "days": 180},
}


def buy_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for code, plan in PLANS.items():
        builder.row(
            InlineKeyboardButton(
                text=f"💳 {plan['name']} — {plan['price']} ₽",
                callback_data=f"fk:{code}",
            )
        )
    builder.row(InlineKeyboardButton(text="🏠 Главная", callback_data="menu:home"))
    return builder.as_markup()


@router.callback_query(F.data == "menu:buy")
async def show_buy_menu(callback: CallbackQuery) -> None:
    await callback.answer()
    text = (
        "💳 <b>Оформление подписки</b>\n\n"
        "Выберите тариф и оплатите картой или через СБП.\n"
        "Доступ активируется автоматически сразу после оплаты."
    )
    if callback.message.photo:
        await callback.message.edit_caption(caption=text, reply_markup=buy_keyboard())
    else:
        await callback.message.edit_text(text, reply_markup=buy_keyboard())


FK_PAY_URL = "https://pay.freekassa.ru/"


def freekassa_link(order_id: str, amount: int) -> str | None:
    merchant = os.getenv("FREEKASSA_MERCHANT_ID", "")
    secret1 = os.getenv("FREEKASSA_SECRET1", "")
    if not merchant or not secret1:
        return None
    sign = hashlib.md5(f"{merchant}:{amount}:{secret1}:RUB:{order_id}".encode()).hexdigest()
    return FK_PAY_URL + "?" + urlencode(
        {"m": merchant, "oa": amount, "currency": "RUB", "o": order_id, "s": sign}
    )


@router.callback_query(F.data.startswith("fk:"))
async def process_fk_buy(callback: CallbackQuery) -> None:
    await callback.answer()
    code = callback.data.split(":")[1]
    plan = PLANS.get(code)
    if not plan:
        return
    async with SessionFactory() as session:
        customer = (
            await session.execute(
                select(Customer).where(Customer.telegram_id == callback.from_user.id)
            )
        ).scalars().first()
        if not customer:
            customer = Customer(
                telegram_id=callback.from_user.id,
                telegram_username=callback.from_user.username,
                full_name=callback.from_user.full_name or "",
            )
            session.add(customer)
            await session.flush()
        tx = PaymentTransaction(
            customer_id=customer.id,
            amount=plan["price"],
            currency="RUB",
            provider="freekassa",
            payload=code,
            status=PaymentStatus.pending,
        )
        session.add(tx)
        await session.commit()
        order_id = tx.id

    link = freekassa_link(order_id, plan["price"])
    if not link:
        await callback.message.answer("Оплата картой временно недоступна. Напишите в поддержку.")
        return
    kb = InlineKeyboardBuilder()
    kb.row(InlineKeyboardButton(text=f"💳 Оплатить {plan['price']} ₽", url=link))
    kb.row(InlineKeyboardButton(text="🏠 Главная", callback_data="menu:home"))
    text = (
        f"💳 <b>Оплата тарифа {plan['name']}</b>\n\n"
        f"Сумма: <b>{plan['price']} ₽</b>\n"
        "Способы: банковская карта, СБП.\n\n"
        "Нажмите кнопку ниже. После оплаты подписка активируется автоматически."
    )
    if callback.message.photo:
        await callback.message.edit_caption(
            caption=text, reply_markup=kb.as_markup(), parse_mode="HTML"
        )
    else:
        await callback.message.edit_text(text, reply_markup=kb.as_markup(), parse_mode="HTML")


@router.callback_query(F.data.startswith("buy:"))
async def process_buy(callback: CallbackQuery) -> None:
    await callback.answer()
    code = callback.data.split(":")[1]
    plan = PLANS.get(code)
    if not plan:
        return

    # LabeledPrice is required for Telegram Stars, currency must be "XTR"
    prices = [LabeledPrice(label=plan["name"], amount=plan["price"])]

    await callback.message.answer_invoice(
        title=f"Подписка {plan['name']}",
        description="Безлимитный доступ к HamaliVPN на максимальной скорости.",
        payload=f"sub:{code}",
        provider_token="",  # Empty for Telegram Stars
        currency="XTR",
        prices=prices,
    )


@router.pre_checkout_query()
async def pre_checkout(pre_checkout_q: PreCheckoutQuery) -> None:
    await pre_checkout_q.answer(ok=True)


@router.message(F.successful_payment)
async def successful_payment(message: Message) -> None:
    payment = message.successful_payment
    payload = payment.invoice_payload
    if not payload.startswith("sub:"):
        return

    code = payload.split(":")[1]
    plan = PLANS.get(code)
    if not plan:
        return

    gateway = make_remnawave_gateway(settings)

    async with SessionFactory() as session:
        # Give 10% back to referrer if exists
        customer_stmt = select(Customer).where(Customer.telegram_id == message.from_user.id)
        customer_result = await session.execute(customer_stmt)
        customer = customer_result.scalars().first()

        if customer and customer.referrer_id:
            referrer = await session.get(Customer, customer.referrer_id)
            if referrer:
                bonus = int(plan["price"] * 0.1)
                referrer.balance_rub += bonus
                try:
                    await message.bot.send_message(
                        referrer.telegram_id,
                        f"🎁 Ваш реферал только что оплатил подписку!\n"
                        f"Вам начислено <b>{bonus} ⭐️</b> на внутренний баланс.",
                        parse_mode="HTML"
                    )
                except Exception:
                    pass

        # Extend or create subscription
        subscription = await get_latest_subscription(session, message.from_user.id)
        provisioned_now = False
        if not subscription:
            # No subscription yet — provision a Remnawave user via the standard flow.
            try:
                sub_result = await issue_trial(
                    session,
                    gateway,
                    settings,
                    telegram_id=message.from_user.id,
                    telegram_username=message.from_user.username,
                    full_name=message.from_user.full_name,
                )
                subscription = await session.get(Subscription, sub_result.subscription_id)
                provisioned_now = True
            except RemnawaveError:
                logger.exception("Failed to provision subscription after payment")

        if subscription:
            now = datetime.now(UTC)
            if provisioned_now:
                # issue_trial grants the long-lived test window (test_access_days);
                # a paid plan must measure its term from "now", not from that sentinel.
                base = now
            else:
                # Top up an existing subscription: extend from the later of "now"
                # and the current expiry so active time is never lost.
                current_expiry = (
                    as_utc(subscription.expires_at) if subscription.expires_at else now
                )
                base = max(current_expiry, now)
            new_expires = base + timedelta(days=plan["days"])

            subscription.expires_at = new_expires
            subscription.status = SubscriptionStatus.active
            await session.commit()

            # Extend in Remnawave
            if subscription.remnawave_uuid:
                try:
                    remote = await gateway.update_user_access(
                        user_uuid=subscription.remnawave_uuid,
                        expires_at=new_expires,
                        device_limit=subscription.device_limit,
                        traffic_limit_bytes=subscription.traffic_limit_gb * 1024**3,
                        squads=settings.squad_uuids,
                    )
                    subscription.subscription_url = remote.subscription_url
                    subscription.remnawave_short_uuid = remote.short_uuid
                    await session.commit()
                except Exception:
                    logger.exception("Failed to update remnawave user expiration")
        else:
            logger.error(
                "Payment succeeded, but subscription was not created",
                extra={"telegram_id": message.from_user.id, "payload": payload},
            )
            await message.answer(
                "✅ Оплата прошла, но доступ не выдался автоматически.\n"
                "Напишите в поддержку — мы вручную активируем подписку.",
                parse_mode="HTML",
            )
            return

    text = (
        f"✅ <b>Оплата прошла успешно!</b>\n\n"
        f"Вы приобрели тариф <b>{plan['name']}</b>.\n"
        f"Подписка продлена до {subscription.expires_at.strftime('%d.%m.%Y')}."
    )
    await message.answer(text, parse_mode="HTML")
